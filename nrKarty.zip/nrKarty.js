const fs = require('fs');

let rawUsers = fs.readFileSync('users.json');
let users = JSON.parse(rawUsers);
let rawKarty = fs.readFileSync('karty.json');
let karty = JSON.parse(rawKarty);
let usersOutput = []

users.forEach(user => {
    karty.forEach(karta => {
        if (user.login == karta.login) {
            user.nrKarty = karta.nrKarty
            usersOutput.push(user);
        }
    });
});

let diff = users.filter(x => !usersOutput.includes(x));
let usersOutputToFile = usersOutput.concat(diff);
const data = JSON.stringify(usersOutputToFile);
fs.writeFileSync('usersOutput.json', data)
